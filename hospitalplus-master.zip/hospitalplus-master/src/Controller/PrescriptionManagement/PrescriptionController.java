/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller.PrescriptionManagement;

import dao.interfaces.PrescriptionDao;
import daoFactory.DaoFactory;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Prescription;

/**
 *
 * @author hp
 */
public class PrescriptionController {
    
    private static PrescriptionController presc = new PrescriptionController();
    
    public PrescriptionController(){
        
    }
    
    private static PrescriptionDao PrescriptDao() throws IOException {
        DaoFactory dao = DaoFactory.getDatabase();
        return dao.getPrescriptionDao();
    }

    public static PrescriptionController getPresc() {
        return presc;
    }
    
    public Prescription addPrescription(Prescription prescription) throws SQLException {
        if (prescription != null) {
            prescription.prescriptionSubmit();
        }
        return prescription;
    }
    public ArrayList<Prescription> getAllPrescriptionData() throws IOException{
        
        return PrescriptDao().getAllData();
        
    }
    public Prescription getPrescriptionById(String id) throws IOException{
        return PrescriptDao().getEmployeeFromId(id);
    }
    
    public Prescription update(Prescription prescription) throws SQLException {
        if (prescription != null) {
            prescription.update();
        }
        return prescription;
    }
    public void delete(int id) throws SQLException {
        Prescription.delete(id);
    }
        
}
