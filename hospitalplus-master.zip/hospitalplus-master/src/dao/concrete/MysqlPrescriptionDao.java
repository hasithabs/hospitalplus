/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.concrete;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dao.interfaces.PrescriptionDao;
import daoFactory.DaoFactory;
import java.sql.Date;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import model.Prescription;
import org.apache.log4j.Logger;
import util.Config;
import util.DBUtil;
import static util.DBUtil.getXMLData;

/**
 *
 * @author hp
 */

public class MysqlPrescriptionDao implements PrescriptionDao{
    Config cnf = new Config();
    public Logger LOG;
    
    PreparedStatement pstmt;
    ResultSet rset;
    String query;
    Connection con;

    public MysqlPrescriptionDao() {
        //initialize log file
        LOG = cnf.getLogger(MysqlPrescriptionDao.class);
    }
    /*
    public void insert(Prescription prescription) throws SQLException {
        Connection c = DaoFactory.getDatabase().openConnection();
        
        PreparedStatement statement = c.prepareStatement(DBUtil.getXMLData("PrescriptionQuery", "query", "Prescription_Insert"));
        
        statement.setString(1, prescription.getPatientName());
        statement.setString(2, prescription.getPatientID());
        statement.setString(3, prescription.getAge());
        statement.setString(4, prescription.getSex());
        statement.setString(5, prescription.getPrescriptionID());
        statement.setDate(6, prescription.getCreateDate());
        statement.setString(7, prescription.getDrugName());
        statement.setString(8, prescription.getDosage());
        statement.setString(8, prescription.getFrequency());
        statement.setString(10, prescription.getPeroid());
        
        statement.executeUpdate();
        
        statement.close();
        c.close();
    }
    */
    @Override
    public Prescription insert(Prescription prescription) throws SQLException { 
    
        try{
            Connection con = DaoFactory.getDatabase().openConnection();
            try{
                PreparedStatement statement = con.prepareStatement(getXMLData("PrescriptionQuery", "query", "PrescriptionInsert"), PreparedStatement.RETURN_GENERATED_KEYS);
                statement.setString(1, prescription.getPatientName());
                statement.setInt(2, prescription.getPatientID());
                statement.setString(3, prescription.getAge());
                statement.setString(4, prescription.getSex());
                //statement.setInt(5, prescription.getPrescriptionID());
                statement.setDate(5, prescription.getCreateDate());
                statement.setString(6, prescription.getDrugName());
                statement.setString(7, prescription.getDosage());
                statement.setString(8, prescription.getFrequency());
                statement.setString(9, prescription.getPeroid());
                
                statement.executeUpdate();
                
                con.close();
                
            }catch(Exception ee){
                LOG.error(ee);
            }
        }catch(Exception e){
            LOG.error(e);
        }
        return prescription;
    }

    @Override
    public Prescription update(Prescription prescription) throws SQLException {
        try {
            Connection con = DaoFactory.getDatabase().openConnection();
            try {
                PreparedStatement pstmt = con.prepareStatement(getXMLData("PrescriptionQuery", "query", "PrescriptionUpdate"), PreparedStatement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, prescription.getPatientName());
                pstmt.setString(2, prescription.getAge());
                pstmt.setString(3, prescription.getSex());
                pstmt.setDate(4, prescription.getCreateDate());
                pstmt.setString(5, prescription.getDrugName());
                pstmt.setString(6, prescription.getDosage());
                pstmt.setString(7, prescription.getFrequency());
                pstmt.setString(8, prescription.getPeroid()); 
                
                pstmt.executeUpdate();
                
                con.close();
            }catch(Exception ee){
                LOG.error(ee);
            }
        }catch(Exception ee){
            LOG.error(ee);
        }
        return prescription;
    }

    @Override
    public void delete(int id) throws SQLException {
        try {
            Connection con = DaoFactory.getDatabase().openConnection();
            try {
                PreparedStatement pstmt = con.prepareStatement(getXMLData("PrescriptionQuery", "query", "PrescriptionDelete"), PreparedStatement.RETURN_GENERATED_KEYS);
                pstmt.setInt(1, id);
                
                pstmt.executeUpdate();
            }catch(Exception ee){
                LOG.error(ee);
            }
        }catch(Exception ee){
            LOG.error(ee);
        }
        
    }

    @Override
    public ArrayList<Prescription> getAllData() {
        ArrayList<Prescription> PrescriptionList = new ArrayList<>();
        
        try {
            //reading query from xml file
            query = DBUtil.getXMLData("PrescriptionQuery", "query", "prescriptiontDetails");
            pstmt = con.prepareStatement(query);
            rset = pstmt.executeQuery(query);

            Prescription pres;
            while (rset.next()) {
                pres = new Prescription();
                pres.setPatientName(rset.getString("Patient name"));
                pres.setPatientID(rset.getInt("Patient ID"));
                pres.setAge(rset.getString("Age"));
                pres.setSex(rset.getString("Sex"));
                pres.setPrescriptionID(rset.getInt("Prescription ID"));
                pres.setCreateDate(rset.getDate("Create Date"));
                pres.setDrugName(rset.getString("Drug name"));
                pres.setDosage(rset.getString("Dosage"));
                pres.setFrequency(rset.getString("Frequency"));
                pres.setPeroid(rset.getString("Period"));
                
                PrescriptionList.add(pres);
            }

        } catch (SQLException e) {
            LOG.error(e, e);
        }

        return PrescriptionList;
    }

    @Override
    public Prescription getEmployeeFromId(String Id) {
        Prescription presc = new Prescription();
        query = DBUtil.getXMLData("PrescriptionQuery", "query", "PrescriptionSelectAllById");
        try {

            pstmt = con.prepareStatement(query);
            pstmt.setString(2, Id);
            rset = pstmt.executeQuery();
         
           
            while (rset.next()) {
                
                presc.setPatientName(rset.getString("Patient name"));
                presc.setPatientID(rset.getInt("Patient ID"));
                presc.setAge(rset.getString("Age"));
                presc.setSex(rset.getString("Sex"));
                presc.setPrescriptionID(rset.getInt("Prescription ID"));
                presc.setCreateDate(rset.getDate("Create Date"));
                presc.setDrugName(rset.getString("Drug name"));
                presc.setDosage(rset.getString("Dosage"));
                presc.setFrequency(rset.getString("Frequency"));
                presc.setPeroid(rset.getString("Period"));
            }

        } catch (SQLException e) {
            LOG.error(e, e);
        }
        return presc;
    }
}
