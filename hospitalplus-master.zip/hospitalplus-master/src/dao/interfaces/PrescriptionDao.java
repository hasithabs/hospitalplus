/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interfaces;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Prescription;
/**
 *
 * @author hp
 */
public interface PrescriptionDao {
    Prescription insert(Prescription prescription) throws SQLException;
    public ArrayList<Prescription> getAllData();
    public Prescription getEmployeeFromId(String Id);
    Prescription update(Prescription prescription) throws SQLException;
    void delete(int id) throws SQLException;
}
