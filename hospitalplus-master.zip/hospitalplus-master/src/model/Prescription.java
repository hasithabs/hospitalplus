/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;
import java.sql.SQLException;

import dao.interfaces.PrescriptionDao;
import daoFactory.DaoFactory;

/**
 *
 * @author hp
 */
public class Prescription {
    private String patientName;
    private int patientID;
    private String age;
    private String sex;
    private int prescriptionID;
    private Date createDate;
    private String drugName;
    private String dosage;
    private String frequency;
    private String peroid;
    
    public Prescription(String pName, String pID, String pAge, String pSex, Date cDate, String dName, String dDosage, String dFrequency, String dPeriod){
        this.patientName = pName;
        this.patientID = Integer.parseInt(pID);
        this.age = pAge;
        this.sex = pSex;
        //this.prescriptionID = Integer.parseInt(prescID);
        this.createDate = cDate;
        this.drugName = dName;
        this.dosage = dDosage;
        this.frequency = dFrequency;
        this.peroid = dPeriod;
    }

    public Prescription() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }
    
    public int getPrescriptionID() {
        return prescriptionID;
    }

    public void setPrescriptionID(int prescriptionID) {
        this.prescriptionID = prescriptionID;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getDrugName() {
        return drugName;
    }

    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getPeroid() {
        return peroid;
    }

    public void setPeroid(String peroid) {
        this.peroid = peroid;
    }
    
    public void prescriptionSubmit() throws SQLException {
        prescriptionDAO().insert(this);
    }
    
    public Prescription update() throws SQLException {
        return prescriptionDAO().update(this);
    }
    
    public static void delete(int id) throws SQLException {
        prescriptionDAO().delete(id);
    }
    
    private static PrescriptionDao prescriptionDAO() {
        DaoFactory dao = DaoFactory.getDatabase();
        return dao.getPrescriptionDao();
    }
}
